preview stub scene package
